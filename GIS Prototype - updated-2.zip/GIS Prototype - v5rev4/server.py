from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import mysql.connector
from flask_cors import cross_origin
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__, static_url_path='/static', template_folder='templates')
CORS(app)


# MySQL Connection Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/gis'
app.config['SQLALCHEMY_POOL_SIZE'] = 32  # Adjust the pool size as needed
db = SQLAlchemy(app)


class Project(db.Model):
    __tablename__ = 'projects'  # Specify the correct table name
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    status = db.Column(db.String(255), default='Active', nullable=False)
    priority = db.Column(db.Integer)


class Department(db.Model):
    __tablename__ = 'departments'  # Specify the correct table name
    department_id = db.Column(db.Integer, primary_key=True)
    department_name = db.Column(db.String(255))


# MySQL Connection Pooling
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "gis",
    
}


def link_with_mysql():
    global mydb
    print("MySQL Connection Pooling is configured")
    print("APIs are running on http://localhost:5000")
    print("Press Ctrl+C to stop the server")
    print("=====================================")
    mydb=mysql.connector.connect(pool_name="mypool", pool_size=32, **db_config)

    return mysql.connector.connect(pool_name="mypool", pool_size=32, **db_config)

def unlink_from_mysql(mydb):
    mydb.close()
    print("MySQL Connection Pooling is closed")
    print("=====================================")


@app.route('/')
def index():
    return open('index.html').read()


@app.route('/login', methods=['OPTIONS', 'POST'])
def login():
    
    # mydb = link_with_mysql()
    
    if request.method == 'OPTIONS':
        # Respond to the preflight request
        response = app.make_default_options_response()
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        # unlink_from_mysql(mydb)
        return response

    if request.method == 'POST':
        data = request.get_json()
        username = data['username']
        password = data['password']

        cursor = mydb.cursor(dictionary=True)

        # Use parameterized query to prevent SQL injection
        query = "SELECT * FROM users WHERE username = %s AND password = %s"
        cursor.execute(query, (username, password))

        user = cursor.fetchone()
        cursor.close()

        if user:
            redirect_url = f"/dashboard?role={user['role']}"
            # unlink_from_mysql(mydb)
            return jsonify({"status": "success", "role": user["role"], "redirect_url": redirect_url})
        else:
            # unlink_from_mysql(mydb)
            return jsonify({"status": "failure"})


# Add the OPTIONS method to the allowed methods for the route
app.config['CORS_METHODS'] = ['OPTIONS', 'GET', 'POST', 'PUT', 'DELETE']


@app.route('/dashboard', methods=['GET'])
def dashboard():
    user_role = request.args.get('role')

    if user_role == 'admin':
        return render_template('admin_dashboard.html')
    elif user_role == 'manager':
        return render_template('manager_dashboard.html')
    elif user_role == 'user':
        return render_template('user_dashboard.html')
    else:
        return "Invalid role"


"""
CREATE TABLE projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(255) NOT NULL DEFAULT 'Active'
);
"""
@app.route('/projects', methods=['OPTIONS', 'GET', 'POST'])
def projects():
    
    # mydb = link_with_mysql()
    
    if request.method == 'OPTIONS':
        # Respond to the preflight request
        response = app.make_default_options_response()
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        return response

    if request.method == 'GET':
        records = Project.query.all()
        projects = [{"id": record.id, "name": record.name, "description": record.description, "status": record.status,"priority":record.priority} for record in records]
        return jsonify(projects)

    if request.method == 'POST':
        data = request.get_json()
        name = data['name']
        description = data['description']
        priority = data['priority']  # Get the priority from the form

        new_project = Project(name=name, description=description, priority=priority)
        db.session.add(new_project)
        db.session.commit()
        return jsonify({"status": "success"})

    return jsonify({"status": "failure"})

@app.route('/projects/<int:project_id>', methods=['GET'])
def get_project(project_id):
    try:
        project = Project.query.get(project_id)
        if project:
            return jsonify({
                "id": project.id,
                "name": project.name,
                "description": project.description,
                "status": project.status,
                "priority": project.priority
            })
        else:
            return jsonify({"error": "Project not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500



@app.route('/projects/<int:project_id>', methods=['PUT'])
def update_project(project_id):
    
    print("running")
    global mydb 
    if request.method == 'PUT':
        if mydb is None:
            print("running 2")
            mydb = link_with_mysql()
            return jsonify({"status": "failure", "error": "Database connection not established"})

        data = request.get_json()
        name = data['name']
        description = data['description']
        priority = data['priority']
        
        try:
            cursor = mydb.cursor(dictionary=True)
            print(f"Received Data - Name: {name}, Description: {description}, Priority: {priority}")


            # Use parameterized query to update the project
            query = "UPDATE projects SET name = %s, description = %s, priority = %s WHERE id = %s"
            cursor.execute(query, (name, description, priority, project_id))
            print("running 3")
            mydb.commit()
            cursor.close()
            unlink_from_mysql(mydb)  # Ensure you close the connection
            print("Project updated successfully")
            return jsonify({"status": "success"})
        except Exception as e:
            # Log the exception to help with debugging
            print(f"Error updating project: {str(e)}")
            return jsonify({"status": "failure", "error": str(e)})
    
    return jsonify({"status": "failure"})

"""
CREATE TABLE tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(255) NOT NULL DEFAULT 'Pending',
    assignee VARCHAR(255),
    FOREIGN KEY (project_id) REFERENCES projects(id)
);
"""



@app.route('/tasks', methods=['OPTIONS', 'GET', 'POST'])
def tasks():
    
    mydb = link_with_mysql()
    
    if request.method == 'OPTIONS':
        # Respond to the preflight request
        response = app.make_default_options_response()
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        unlink_from_mysql(mydb)
        return response

    if request.method == 'GET':
        cursor = mydb.cursor(dictionary=True)
        cursor.execute("""
        SELECT tasks.*, projects.name AS project_name, departments.department_name AS department_name
        FROM tasks
        LEFT JOIN projects ON tasks.project_id = projects.id
        LEFT JOIN departments ON tasks.department_id = departments.department_id
    """)
        records = cursor.fetchall()
        cursor.close()
        unlink_from_mysql(mydb)
        return jsonify(records)

    if request.method == 'POST':
        data = request.get_json()
        project_id = data['project_id']
        department_id=data['department_id']
        department_name=data['department_name']
        name = data['name']
        description = data['description']
        assignee = data['assignee']
        duration = data['days']  # Get the duration from the form
        comment = data['comment']  # Get the comment from the request
        print("Received data:", data)
        cursor = mydb.cursor(dictionary=True)
        
        # Use parameterized query to prevent SQL injection
        query = "INSERT INTO tasks (project_id, name, description, assignee, duration, comment,department_id) VALUES (%s, %s, %s, %s, %s,%s,%s)"
        cursor.execute(query, (project_id, name, description, assignee, duration, comment,department_id))
        
        project_department_query = "INSERT INTO projectdepartments (project_id,department_id) VALUES (%s,%s)"
        cursor.execute(project_department_query, (project_id,department_id))

        mydb.commit()
        cursor.close()
        unlink_from_mysql(mydb)
        return jsonify({"status": "success"})
    unlink_from_mysql(mydb)
    return jsonify({"status": "failure"})

@app.route('/tasks/<int:task_id>', methods=['GET'])
def get_task(task_id):
    mydb = link_with_mysql()
    
    # Check if the task ID exists in the database
    cursor = mydb.cursor(dictionary=True)
    cursor.execute("""
    SELECT tasks.*, projects.name AS project_name, departments.department_name AS department_name
    FROM tasks
    LEFT JOIN projects ON tasks.project_id = projects.id
    LEFT JOIN departments ON tasks.department_id = departments.department_id
    WHERE tasks.id = %s
    """, (task_id,))
    task = cursor.fetchone()
    cursor.close()

    unlink_from_mysql(mydb)

    if task:
        return jsonify(task)
    else:
        return jsonify({"error": "Task not found"}), 404
    
@app.route('/tasks/<int:task_id>', methods=['POST'])
def update_task(task_id):
    mydb = link_with_mysql()

    if request.method == 'POST':
        data = request.get_json()
        name = data['name']
        description = data['description']
        assignee = data['assignee']
        # duration = data['duration']
        comment = data['comment']
        try:
            cursor = mydb.cursor(dictionary=True)
            print(f"Received Data - Name: {name}, Description: {description}, Assignee: {assignee},Comment{comment}")

            # Use parameterized query to update the task
            query = "UPDATE tasks SET name = %s, description = %s, assignee = %s ,comment=%s WHERE id = %s"
            cursor.execute(query, (name, description, assignee,comment, task_id))

            mydb.commit()
            cursor.close()
            unlink_from_mysql(mydb)  # Ensure you close the connection
            print("Task updated successfully")
            return jsonify({"status": "success"})
        except Exception as e:
            # Log the exception to help with debugging
            print(f"Error updating task: {str(e)}")
            return jsonify({"status": "failure", "error": str(e)})

    return jsonify({"status": "failure"})

@app.route('/tasks_manager/<int:task_id>', methods=['GET','POST'])
def update_task_manager(task_id):
    mydb = link_with_mysql()

    if request.method == 'POST':
        data = request.get_json()
    
        comment = data['comment_manager']
        try:
            cursor = mydb.cursor(dictionary=True)
            print(f"Received Data - Comment{comment}",task_id)

            # Use parameterized query to update the task
            query = "UPDATE tasks SET comment_manager=%s WHERE id = %s"
            cursor.execute(query, ( comment,task_id))

            mydb.commit()
            cursor.close()
            unlink_from_mysql(mydb)  # Ensure you close the connection
            print("Task updated successfully")
            return jsonify({"status": "success"})
        except Exception as e:
            # Log the exception to help with debugging
            print(f"Error updating task: {str(e)}")
            return jsonify({"status": "failure", "error": str(e)})

    return jsonify({"status": "failure"})
@app.route('/tasks_user/<int:task_id>', methods=['GET','POST'])
def update_task_user(task_id):
    mydb = link_with_mysql()

    if request.method == 'POST':
        data = request.get_json()
    
        comment = data['comment_user']
        try:
            cursor = mydb.cursor(dictionary=True)
            print(f"Received Data - Comment{comment}",task_id)

            # Use parameterized query to update the task
            query = "UPDATE tasks SET comment_user=%s WHERE id = %s"
            cursor.execute(query, ( comment,task_id))

            mydb.commit()
            cursor.close()
            unlink_from_mysql(mydb)  # Ensure you close the connection
            print("Task updated successfully")
            return jsonify({"status": "success"})
        except Exception as e:
            # Log the exception to help with debugging
            print(f"Error updating task: {str(e)}")
            return jsonify({"status": "failure", "error": str(e)})

    return jsonify({"status": "failure"})

@app.route('/get_departments', methods=['GET'])
def get_departments():
    departments = Department.query.all()
    department_list = [{"department_id": department.department_id, "department_name": department.department_name} for department in departments]
    return jsonify({"departments": department_list})


# APIs to delete a project or task
@app.route('/delete', methods=['OPTIONS', 'POST'])
def delete():
    
    mydb = link_with_mysql()
    
    if request.method == 'OPTIONS':
        # Respond to the preflight request
        response = app.make_default_options_response()
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        unlink_from_mysql(mydb)
        return response

    if request.method == 'POST':
        data = request.get_json()
        table = data['table']
        id = data['id']

        cursor = mydb.cursor(dictionary=True)

        # Use parameterized query to prevent SQL injection
        query = f"DELETE FROM {table} WHERE id = %s"
        cursor.execute(query, (id,))

        mydb.commit()
        cursor.close()
        unlink_from_mysql(mydb)
        return jsonify({"status": "success"})
    unlink_from_mysql(mydb)
    return jsonify({"status": "failure"})


# API to handle logout
@app.route('/logout', methods=['OPTIONS', 'POST'])
def logout():
    
    mydb = link_with_mysql()
    
    if request.method == 'OPTIONS':
        # Respond to the preflight request
        response = app.make_default_options_response()
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        unlink_from_mysql(mydb)
        return response

    if request.method == 'POST':
        unlink_from_mysql(mydb)
        return jsonify({"status": "success"})
    unlink_from_mysql(mydb)
    return jsonify({"status": "failure"})


if __name__ == "__main__":
    app.run(debug=True)
